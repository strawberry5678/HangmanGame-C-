﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace HangmanGame
{
    public partial class HangmanForm : Form
    {
        private readonly string[] wordList = { "addition", "substraction", "multiplication", "division", "remainder" ,"equal", "mathematics","algorithm","formula","plus"};
        private string currentWord;
        private ArrayList correctGuesses;
        private ArrayList incorrectGuesses;
        private SortedList<string, int> scoreboard;

        private int maxWrongGuesses = 10;
        private int wrongGuessCount;

        public HangmanForm()
        {
            InitializeComponent();
            InitializeGame();
        }

        private void InitializeGame()
        {
            currentWord = SelectRandomWord();
            correctGuesses = new ArrayList();
            incorrectGuesses = new ArrayList();
            scoreboard = new SortedList<string, int>();
            wrongGuessCount = 0;

            DisplayWord();
            DisplayScoreboard();
        }

        private string SelectRandomWord()
        {
            Random random = new Random();
            return wordList[random.Next(wordList.Length)];
        }

        private void DisplayWord()
        {
            wordLabel.Text = "";
            foreach (char letter in currentWord)
            {
                if (correctGuesses.Contains(letter))
                {
                    wordLabel.Text += letter + " ";
                }
                else
                {
                    wordLabel.Text += "_ ";
                }
            }
        }

        private void DisplayScoreboard()
        {
            scoreboardListBox.Items.Clear();
            foreach (var score in scoreboard)
            {
                scoreboardListBox.Items.Add($"{score.Key}: {score.Value} guesses");
            }
        }

        private void CheckGuess(char guess)
        {
            if (currentWord.Contains(guess))
            {
                correctGuesses.Add(guess);
            }
            else
            {
                incorrectGuesses.Add(guess);
                wrongGuessCount++;
            }

            DisplayWord();
            DisplayIncorrectGuesses();

            if (wrongGuessCount >= maxWrongGuesses)
            {
                EndGame(false);
            }
            else if (!wordLabel.Text.Contains("_"))
            {
                EndGame(true);
            }
        }

        private void DisplayIncorrectGuesses()
        {
            incorrectLabel.Text = string.Join(", ", incorrectGuesses.Cast<char>());
        }

        private void EndGame(bool isWinner)
        {
            if (isWinner)
            {
                MessageBox.Show("WOW,GREAT! You guessed the right word.");
                scoreboard.Add(currentWord, correctGuesses.Count);
            }
            else
            {
                MessageBox.Show($"OOPs, you ran out of guesses. The word was: {currentWord}");
            }

            InitializeGame();
        }

        private void HangmanForm_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                char guess = char.ToLower(e.KeyChar);
                if (!correctGuesses.Contains(guess) && !incorrectGuesses.Contains(guess))
                {
                    CheckGuess(guess);
                }
            }
        }

      

        private void button3_Click(object sender, EventArgs e)
        {
            InitializeGame();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}




























/*private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
        enum Bodyparts
        {
            Head,
            Left_Eye,
            Right_Eye,
            Mouth,
            Right_Arm,
            Left_Arm,
            Body,
            Right_Leg,
            Left_leg

        }

        void DrawHangPost()
        {
            Graphics g = panel1.CreateGraphics();
            Pen p = new Pen(Color.Brown, 10);
            g.DrawLine(p, new Point(130, 218), new Point(130, 5));
            g.DrawLine(p, new Point(135, 5), new Point(65, 5));
            g.DrawLine(p, new Point(69, 0), new Point(60, 50));
            DrawBodyPart(Bodyparts.Head);
            DrawBodyPart(Bodyparts.Left_Eye);
            DrawBodyPart(Bodyparts.Right_Eye);




        }
        void DrawBodyPart(Bodyparts bp)
        {
            Graphics g = panel1.CreateGraphics();
            Pen p = new Pen(Color.Blue);
            if (bp == Bodyparts.Head)
                g.DrawEllipse(p, 40, 50, 40, 40);
            else if(bp == Bodyparts.Left_Eye)
            {
                SolidBrush s = new SolidBrush(Color.Black);
                g.FillEllipse(s, 50, 60, 5, 5);

            }
            else if (bp == Bodyparts.Right_Eye)
            {
                SolidBrush s = new SolidBrush(Color.Black);
                g.FillEllipse(s, 50, 60, 5, 5);

            }
            else if (bp == Bodyparts.Mouth)
            {
                g.DrawArc(p, 50, 60, 20, 20, 45, 90);

            }
        }


        private void Form1_shown(object sender, EventArgs e)
        {
            DrawHangPost();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string submitLwtter = txtSubmitLetter.Text;

        }
    }
}*/
